# CalenderAppointmentApi.AppointmentRequestWithPatient

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dentistId** | **String** | ID of the dentist | [optional] 
**patient** | [**Patient**](Patient.md) |  | [optional] 
**appointmentTime** | **Date** | Date and time of the appointment | [optional] 
**durationInMinutes** | **Number** | Duration of the appointment in minutes | [optional] 
**notes** | **String** | Additional notes for the appointment | [optional] 
**serviceProvided** | **String** | Service provided by the dentist | [optional] 

<a name="ServiceProvidedEnum"></a>
## Enum: ServiceProvidedEnum

* `xRay` (value: `"x-ray"`)
* `rootCanal` (value: `"root canal"`)
* `filling` (value: `"filling"`)
* `reconstruction` (value: `"reconstruction"`)
* `cleaning` (value: `"cleaning"`)
* `whitening` (value: `"whitening"`)
* `veneers` (value: `"veneers"`)
* `extractions` (value: `"extractions"`)

