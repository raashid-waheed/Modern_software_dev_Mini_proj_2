# CalenderAppointmentApi.AppointmentPatchWithPatient

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**appointmentTime** | **Date** | New date and time of the appointment | [optional] 
**durationInMinutes** | **Number** | New duration of the appointment in minutes | [optional] 
**patient** | [**Patient**](Patient.md) |  | [optional] 
