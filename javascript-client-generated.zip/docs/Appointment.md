# CalenderAppointmentApi.Appointment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**appointmentId** | **String** | ID of the appointment | [optional] 
**dentist** | [**Dentist**](Dentist.md) |  | [optional] 
**patient** | [**Patient**](Patient.md) |  | [optional] 
**appointmentTime** | **Date** | Date and time of the appointment | [optional] 
**durationInMinutes** | **Number** | Duration of the appointment in minutes | [optional] 
**notes** | **String** | Additional notes for the appointment | [optional] 
