# CalenderAppointmentApi.Dentist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dentistId** | **String** | ID of the dentist | [optional] 
**name** | **String** | Name of the dentist | [optional] 
**specialty** | **String** | Specialty of the dentist | [optional] 
