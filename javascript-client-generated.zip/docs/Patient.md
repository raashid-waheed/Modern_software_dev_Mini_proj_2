# CalenderAppointmentApi.Patient

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**patientId** | **String** | ID of the patient | [optional] 
**fullName** | **String** | Full name of the patient | [optional] 
**age** | **Number** | Age of the patient | [optional] 
**gender** | **String** | Gender of the patient | [optional] 
