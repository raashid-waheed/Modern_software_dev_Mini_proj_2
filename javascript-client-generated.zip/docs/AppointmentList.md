# CalenderAppointmentApi.AppointmentList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
