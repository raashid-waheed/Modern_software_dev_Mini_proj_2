# CalenderAppointmentApi.DefaultApi

All URIs are relative to *https://virtserver.swaggerhub.com/RAASHIDWAHEED/AppointmentatDentist/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**appointmentsAppointmentIdDelete**](DefaultApi.md#appointmentsAppointmentIdDelete) | **DELETE** /appointments/{appointmentId} | Cancel an appointment
[**appointmentsAppointmentIdGet**](DefaultApi.md#appointmentsAppointmentIdGet) | **GET** /appointments/{appointmentId} | Get details of a specific appointment
[**appointmentsAppointmentIdPatch**](DefaultApi.md#appointmentsAppointmentIdPatch) | **PATCH** /appointments/{appointmentId} | Partially update an existing appointment
[**appointmentsAppointmentIdPut**](DefaultApi.md#appointmentsAppointmentIdPut) | **PUT** /appointments/{appointmentId} | Update an existing appointment
[**appointmentsGet**](DefaultApi.md#appointmentsGet) | **GET** /appointments | Get all appointments
[**appointmentsPost**](DefaultApi.md#appointmentsPost) | **POST** /appointments | Create a new appointment
[**appointmentsSearchGet**](DefaultApi.md#appointmentsSearchGet) | **GET** /appointments/search | Search appointments

<a name="appointmentsAppointmentIdDelete"></a>
# **appointmentsAppointmentIdDelete**
> appointmentsAppointmentIdDelete(appointmentId)

Cancel an appointment

Delete an existing appointment.

### Example
```javascript
import {CalenderAppointmentApi} from 'calender_appointment_api';
let defaultClient = CalenderAppointmentApi.ApiClient.instance;

// Configure API key authorization: apiKey
let apiKey = defaultClient.authentications['apiKey'];
apiKey.apiKey = 'YOUR API KEY';
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//apiKey.apiKeyPrefix = 'Token';

let apiInstance = new CalenderAppointmentApi.DefaultApi();
let appointmentId = "appointmentId_example"; // String | ID of the appointment

apiInstance.appointmentsAppointmentIdDelete(appointmentId, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **appointmentId** | **String**| ID of the appointment | 

### Return type

null (empty response body)

### Authorization

[apiKey](../README.md#apiKey)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="appointmentsAppointmentIdGet"></a>
# **appointmentsAppointmentIdGet**
> Appointment appointmentsAppointmentIdGet(appointmentId)

Get details of a specific appointment

### Example
```javascript
import {CalenderAppointmentApi} from 'calender_appointment_api';
let defaultClient = CalenderAppointmentApi.ApiClient.instance;

// Configure API key authorization: apiKey
let apiKey = defaultClient.authentications['apiKey'];
apiKey.apiKey = 'YOUR API KEY';
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//apiKey.apiKeyPrefix = 'Token';

let apiInstance = new CalenderAppointmentApi.DefaultApi();
let appointmentId = "appointmentId_example"; // String | ID of the appointment

apiInstance.appointmentsAppointmentIdGet(appointmentId, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **appointmentId** | **String**| ID of the appointment | 

### Return type

[**Appointment**](Appointment.md)

### Authorization

[apiKey](../README.md#apiKey)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="appointmentsAppointmentIdPatch"></a>
# **appointmentsAppointmentIdPatch**
> appointmentsAppointmentIdPatch(body, appointmentId)

Partially update an existing appointment

Update specific fields of an existing appointment.

### Example
```javascript
import {CalenderAppointmentApi} from 'calender_appointment_api';
let defaultClient = CalenderAppointmentApi.ApiClient.instance;

// Configure API key authorization: apiKey
let apiKey = defaultClient.authentications['apiKey'];
apiKey.apiKey = 'YOUR API KEY';
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//apiKey.apiKeyPrefix = 'Token';

let apiInstance = new CalenderAppointmentApi.DefaultApi();
let body = new CalenderAppointmentApi.AppointmentPatchWithPatient(); // AppointmentPatchWithPatient | Partially updated appointment details
let appointmentId = "appointmentId_example"; // String | ID of the appointment

apiInstance.appointmentsAppointmentIdPatch(body, appointmentId, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**AppointmentPatchWithPatient**](AppointmentPatchWithPatient.md)| Partially updated appointment details | 
 **appointmentId** | **String**| ID of the appointment | 

### Return type

null (empty response body)

### Authorization

[apiKey](../README.md#apiKey)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

<a name="appointmentsAppointmentIdPut"></a>
# **appointmentsAppointmentIdPut**
> appointmentsAppointmentIdPut(body, appointmentId)

Update an existing appointment

Fully replace an entire existing appointment.

### Example
```javascript
import {CalenderAppointmentApi} from 'calender_appointment_api';
let defaultClient = CalenderAppointmentApi.ApiClient.instance;

// Configure API key authorization: apiKey
let apiKey = defaultClient.authentications['apiKey'];
apiKey.apiKey = 'YOUR API KEY';
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//apiKey.apiKeyPrefix = 'Token';

let apiInstance = new CalenderAppointmentApi.DefaultApi();
let body = new CalenderAppointmentApi.AppointmentRequestWithPatient(); // AppointmentRequestWithPatient | Updated appointment details
let appointmentId = "appointmentId_example"; // String | ID of the appointment

apiInstance.appointmentsAppointmentIdPut(body, appointmentId, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**AppointmentRequestWithPatient**](AppointmentRequestWithPatient.md)| Updated appointment details | 
 **appointmentId** | **String**| ID of the appointment | 

### Return type

null (empty response body)

### Authorization

[apiKey](../README.md#apiKey)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

<a name="appointmentsGet"></a>
# **appointmentsGet**
> AppointmentList appointmentsGet(opts)

Get all appointments

Get a list of all appointments in the calendar.

### Example
```javascript
import {CalenderAppointmentApi} from 'calender_appointment_api';
let defaultClient = CalenderAppointmentApi.ApiClient.instance;

// Configure API key authorization: apiKey
let apiKey = defaultClient.authentications['apiKey'];
apiKey.apiKey = 'YOUR API KEY';
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//apiKey.apiKeyPrefix = 'Token';

let apiInstance = new CalenderAppointmentApi.DefaultApi();
let opts = { 
  'startDate': "startDate_example", // String | Start date of the period
  'endDate': "endDate_example" // String | End date of the period
};
apiInstance.appointmentsGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **startDate** | **String**| Start date of the period | [optional] 
 **endDate** | **String**| End date of the period | [optional] 

### Return type

[**AppointmentList**](AppointmentList.md)

### Authorization

[apiKey](../README.md#apiKey)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="appointmentsPost"></a>
# **appointmentsPost**
> appointmentsPost(body)

Create a new appointment

Create a new appointment for a dentist.

### Example
```javascript
import {CalenderAppointmentApi} from 'calender_appointment_api';
let defaultClient = CalenderAppointmentApi.ApiClient.instance;

// Configure API key authorization: apiKey
let apiKey = defaultClient.authentications['apiKey'];
apiKey.apiKey = 'YOUR API KEY';
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//apiKey.apiKeyPrefix = 'Token';

let apiInstance = new CalenderAppointmentApi.DefaultApi();
let body = new CalenderAppointmentApi.AppointmentRequestWithPatient(); // AppointmentRequestWithPatient | Appointment details

apiInstance.appointmentsPost(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**AppointmentRequestWithPatient**](AppointmentRequestWithPatient.md)| Appointment details | 

### Return type

null (empty response body)

### Authorization

[apiKey](../README.md#apiKey)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

<a name="appointmentsSearchGet"></a>
# **appointmentsSearchGet**
> AppointmentList appointmentsSearchGet(opts)

Search appointments

Search appointments based on different criteria.

### Example
```javascript
import {CalenderAppointmentApi} from 'calender_appointment_api';
let defaultClient = CalenderAppointmentApi.ApiClient.instance;

// Configure API key authorization: apiKey
let apiKey = defaultClient.authentications['apiKey'];
apiKey.apiKey = 'YOUR API KEY';
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//apiKey.apiKeyPrefix = 'Token';

let apiInstance = new CalenderAppointmentApi.DefaultApi();
let opts = { 
  'services': "services_example", // String | Services provided by the dentist
  'customerName': "customerName_example", // String | Customer name
  'startTime': "startTime_example", // String | Start time of the appointment (excluding lunch break)
  'endTime': "endTime_example", // String | End time of the appointment (excluding lunch break)
  'day': "day_example" // String | Day of the week (Monday to Friday)
};
apiInstance.appointmentsSearchGet(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **services** | **String**| Services provided by the dentist | [optional] 
 **customerName** | **String**| Customer name | [optional] 
 **startTime** | **String**| Start time of the appointment (excluding lunch break) | [optional] 
 **endTime** | **String**| End time of the appointment (excluding lunch break) | [optional] 
 **day** | **String**| Day of the week (Monday to Friday) | [optional] 

### Return type

[**AppointmentList**](AppointmentList.md)

### Authorization

[apiKey](../README.md#apiKey)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

