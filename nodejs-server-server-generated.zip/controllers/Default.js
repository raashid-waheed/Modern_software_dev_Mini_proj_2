'use strict';

var utils = require('../utils/writer.js');
var Default = require('../service/DefaultService');

module.exports.appointmentsAppointmentIdDELETE = function appointmentsAppointmentIdDELETE (req, res, next, appointmentId) {
  Default.appointmentsAppointmentIdDELETE(appointmentId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.appointmentsAppointmentIdGET = function appointmentsAppointmentIdGET (req, res, next, appointmentId) {
  Default.appointmentsAppointmentIdGET(appointmentId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.appointmentsAppointmentIdPATCH = function appointmentsAppointmentIdPATCH (req, res, next, body, appointmentId) {
  Default.appointmentsAppointmentIdPATCH(body, appointmentId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.appointmentsAppointmentIdPUT = function appointmentsAppointmentIdPUT (req, res, next, body, appointmentId) {
  Default.appointmentsAppointmentIdPUT(body, appointmentId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.appointmentsGET = function appointmentsGET (req, res, next, startDate, endDate) {
  Default.appointmentsGET(startDate, endDate)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.appointmentsPOST = function appointmentsPOST (req, res, next, body) {
  Default.appointmentsPOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.appointmentsSearchGET = function appointmentsSearchGET (req, res, next, services, customerName, startTime, endTime, day) {
  Default.appointmentsSearchGET(services, customerName, startTime, endTime, day)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
