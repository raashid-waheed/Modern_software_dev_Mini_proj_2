'use strict';


/**
 * Cancel an appointment
 * Delete an existing appointment.
 *
 * appointmentId String ID of the appointment
 * no response value expected for this operation
 **/
exports.appointmentsAppointmentIdDELETE = function(appointmentId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get details of a specific appointment
 *
 * appointmentId String ID of the appointment
 * returns Appointment
 **/
exports.appointmentsAppointmentIdGET = function(appointmentId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "notes" : "notes",
  "appointmentTime" : "2000-01-23T04:56:07.000+00:00",
  "appointmentId" : "appointmentId",
  "patient" : {
    "gender" : "gender",
    "patientId" : "patientId",
    "fullName" : "fullName",
    "age" : 0
  },
  "durationInMinutes" : 6,
  "dentist" : {
    "dentistId" : "dentistId",
    "specialty" : "specialty",
    "name" : "name"
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Partially update an existing appointment
 * Update specific fields of an existing appointment.
 *
 * body AppointmentPatchWithPatient Partially updated appointment details
 * appointmentId String ID of the appointment
 * no response value expected for this operation
 **/
exports.appointmentsAppointmentIdPATCH = function(body,appointmentId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Update an existing appointment
 * Fully replace an entire existing appointment.
 *
 * body AppointmentRequestWithPatient Updated appointment details
 * appointmentId String ID of the appointment
 * no response value expected for this operation
 **/
exports.appointmentsAppointmentIdPUT = function(body,appointmentId) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get all appointments
 * Get a list of all appointments in the calendar.
 *
 * startDate String Start date of the period (optional)
 * endDate String End date of the period (optional)
 * returns AppointmentList
 **/
exports.appointmentsGET = function(startDate,endDate) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "notes" : "notes",
  "appointmentTime" : "2000-01-23T04:56:07.000+00:00",
  "appointmentId" : "appointmentId",
  "patient" : {
    "gender" : "gender",
    "patientId" : "patientId",
    "fullName" : "fullName",
    "age" : 0
  },
  "durationInMinutes" : 6,
  "dentist" : {
    "dentistId" : "dentistId",
    "specialty" : "specialty",
    "name" : "name"
  }
}, {
  "notes" : "notes",
  "appointmentTime" : "2000-01-23T04:56:07.000+00:00",
  "appointmentId" : "appointmentId",
  "patient" : {
    "gender" : "gender",
    "patientId" : "patientId",
    "fullName" : "fullName",
    "age" : 0
  },
  "durationInMinutes" : 6,
  "dentist" : {
    "dentistId" : "dentistId",
    "specialty" : "specialty",
    "name" : "name"
  }
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Create a new appointment
 * Create a new appointment for a dentist.
 *
 * body AppointmentRequestWithPatient Appointment details
 * no response value expected for this operation
 **/
exports.appointmentsPOST = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Search appointments
 * Search appointments based on different criteria.
 *
 * services String Services provided by the dentist (optional)
 * customerName String Customer name (optional)
 * startTime String Start time of the appointment (excluding lunch break) (optional)
 * endTime String End time of the appointment (excluding lunch break) (optional)
 * day String Day of the week (Monday to Friday) (optional)
 * returns AppointmentList
 **/
exports.appointmentsSearchGET = function(services,customerName,startTime,endTime,day) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "notes" : "notes",
  "appointmentTime" : "2000-01-23T04:56:07.000+00:00",
  "appointmentId" : "appointmentId",
  "patient" : {
    "gender" : "gender",
    "patientId" : "patientId",
    "fullName" : "fullName",
    "age" : 0
  },
  "durationInMinutes" : 6,
  "dentist" : {
    "dentistId" : "dentistId",
    "specialty" : "specialty",
    "name" : "name"
  }
}, {
  "notes" : "notes",
  "appointmentTime" : "2000-01-23T04:56:07.000+00:00",
  "appointmentId" : "appointmentId",
  "patient" : {
    "gender" : "gender",
    "patientId" : "patientId",
    "fullName" : "fullName",
    "age" : 0
  },
  "durationInMinutes" : 6,
  "dentist" : {
    "dentistId" : "dentistId",
    "specialty" : "specialty",
    "name" : "name"
  }
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

